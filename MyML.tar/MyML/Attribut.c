/*
 *  Attribut.c
 *
 */

#include "Attribut.h"

/* HERE COMES YOUR CODE */

