Langage myML, un petit langage fonctionel à la ML/Haskell, avec une
syntaxe adhoc. 
